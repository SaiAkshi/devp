import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { Sparkline } from "@/components/Sparkline";
import { fmt } from "@/lib/market";
import { COMPANIES, REGIONS, trendCall } from "@/lib/companies";
import { useLiveQuotes } from "@/lib/use-live";

export const Route = createFileRoute("/market/$region")({
  loader: ({ params }) => {
    const region = REGIONS.find((r) => r.slug === params.region);
    if (!region) throw notFound();
    return { region };
  },
  head: ({ loaderData }) => {
    const label = loaderData?.region.label ?? "Market";
    return {
      meta: [
        { title: `${label} market — TickerTape` },
        { name: "description", content: `Top profitable companies in ${label} with quick insights and trend predictions.` },
        { property: "og:title", content: `${label} market — TickerTape` },
        { property: "og:description", content: `One-line insights and trend calls for leading ${label} companies.` },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: MarketPage,
});

const badge: Record<string, string> = {
  bullish: "bg-gain/15 text-gain",
  bearish: "bg-loss/15 text-loss",
  neutral: "bg-muted text-muted-foreground",
};

function MarketPage() {
  const { region } = Route.useLoaderData();
  const list = COMPANIES[region.slug];
  const { data: live } = useLiveQuotes(list.map((c) => c.symbol));
  const rows = list.map((co) => ({ co, t: trendCall(co, live?.[co.symbol]) }));

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-5 py-10">
        <div className="flex flex-wrap gap-2 font-mono text-xs uppercase">
          {REGIONS.map((r) => (
            <Link key={r.slug} to="/market/$region" params={{ region: r.slug }}
              className="rounded-md border border-border px-3 py-1.5 text-muted-foreground hover:text-foreground"
              activeProps={{ className: "border-primary text-primary" }}>
              {r.label}
            </Link>
          ))}
        </div>
        <p className="mt-8 font-mono text-xs uppercase tracking-widest text-primary">● {region.index} · {live ? "live prices" : "loading live prices…"}</p>
        <h1 className="mt-2 font-display text-4xl font-bold md:text-5xl">{region.label}</h1>
        <p className="mt-2 text-muted-foreground">Top profitable names, a one-line insight on each, and a call based on the current trend. Not financial advice.</p>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {rows.map(({ co, t }) => (
            <article key={co.symbol} className="rounded-lg border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="font-display text-xl font-semibold">{co.name}</h2>
                  <p className="font-mono text-xs text-muted-foreground">
                    {co.symbol}{co.margin > 0 && ` · ${co.margin}% net margin`}
                  </p>
                </div>
                <div className="text-right">
                  <div className="font-mono text-lg">{fmt(t.price)}</div>
                  <div className={`font-mono text-sm ${t.pct >= 0 ? "text-gain" : "text-loss"}`}>
                    {t.pct >= 0 ? "▲" : "▼"} {Math.abs(t.pct).toFixed(2)}%
                  </div>
                </div>
              </div>
              <Sparkline data={t.series} up={t.pct >= 0} />
              <p className="mt-3 text-sm"><span className="font-mono text-xs uppercase text-primary">Insight · </span>{co.insight}</p>
              <p className="mt-2 flex items-center gap-2 text-sm">
                <span className={`rounded px-2 py-0.5 font-mono text-xs uppercase ${badge[t.direction]}`}>{t.direction}</span>
                <span className="text-muted-foreground">{t.text}</span>
              </p>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}
