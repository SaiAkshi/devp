import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader, useUser } from "@/components/SiteHeader";
import { ASSETS, quote } from "@/lib/market";
import { generateAiPrediction } from "@/lib/ai-predict.functions";

export const Route = createFileRoute("/predictions")({
  head: () => ({
    meta: [
      { title: "Predictions — TickerTape" },
      { name: "description", content: "Past and upcoming market predictions from the community and AI." },
      { property: "og:title", content: "Market predictions — TickerTape" },
      { property: "og:description", content: "Read past calls and upcoming forecasts for global stocks and indices." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Predictions,
});

type Prediction = {
  id: string; symbol: string; title: string; body: string; direction: string;
  target_date: string; source: string; author_name: string | null; author_id: string | null; created_at: string;
};

const dirStyle: Record<string, string> = {
  bullish: "bg-gain/15 text-gain",
  bearish: "bg-loss/15 text-loss",
  neutral: "bg-muted text-muted-foreground",
};

function Card({ p, mine, onDelete }: { p: Prediction; mine: boolean; onDelete: () => void }) {
  return (
    <article className="rounded-lg border border-border bg-card p-5">
      <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
        <span className="font-semibold text-foreground">{p.symbol}</span>
        <span className={`rounded px-2 py-0.5 uppercase ${dirStyle[p.direction] ?? dirStyle['neutral']}`}>{p.direction}</span>
        <span className="rounded border border-border px-2 py-0.5 text-muted-foreground">{p.source === "ai" ? "AI" : p.author_name ?? "Member"}</span>
        <span className="ml-auto text-muted-foreground">Target {p.target_date}</span>
      </div>
      <h3 className="mt-3 font-display text-lg font-semibold">{p.title}</h3>
      <p className="mt-1 text-sm text-muted-foreground">{p.body}</p>
      {mine && (
        <button onClick={onDelete} className="mt-3 font-mono text-xs text-loss hover:underline">Delete</button>
      )}
    </article>
  );
}

function Predictions() {
  const user = useUser();
  const qc = useQueryClient();
  const [tab, setTab] = useState<"upcoming" | "past">("upcoming");
  const [aiSymbol, setAiSymbol] = useState("^GSPC");
  const [aiBusy, setAiBusy] = useState(false);
  const [form, setForm] = useState({ symbol: "", title: "", body: "", direction: "bullish", target_date: "" });

  const { data = [], isLoading } = useQuery({
    queryKey: ["predictions"],
    queryFn: async () => {
      const { data, error } = await supabase.from("predictions").select("*").order("target_date", { ascending: true });
      if (error) throw error;
      return data as Prediction[];
    },
  });
  const today = new Date().toISOString().slice(0, 10);
  const upcoming = data.filter((p) => p.target_date >= today);
  const past = data.filter((p) => p.target_date < today).reverse();
  const list = tab === "upcoming" ? upcoming : past;
  const refresh = () => qc.invalidateQueries({ queryKey: ["predictions"] });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    const { error } = await supabase.from("predictions").insert({
      ...form, symbol: form.symbol.toUpperCase(), source: "user", author_id: user.id, author_name: user.email?.split("@")[0] ?? null,
    });
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Prediction posted");
    setForm({ symbol: "", title: "", body: "", direction: "bullish", target_date: "" });
    refresh();
  }

  async function runAi() {
    const a = ASSETS.find((x) => x.symbol === aiSymbol);
    if (!a) return;
    setAiBusy(true);
    try {
      await generateAiPrediction({ data: { symbol: a.symbol, name: a.name, price: Math.round(quote(a).price * 100) / 100 } });
      toast.success("AI prediction added");
      setTab("upcoming");
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not generate");
    } finally {
      setAiBusy(false);
    }
  }

  async function remove(id: string) {
    const { error } = await supabase.from("predictions").delete().eq("id", id);
    if (error) toast.error(error.message);
    refresh();
  }

  const input = "w-full rounded-md border border-input bg-background px-3 py-2 text-sm";

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto grid max-w-6xl gap-10 px-5 py-10 lg:grid-cols-[1fr_340px]">
        <section>
          <h1 className="font-display text-4xl font-bold">Predictions</h1>
          <p className="mt-1 text-muted-foreground">Calls from members and AI. For reading only — not financial advice.</p>
          <div className="mt-6 flex gap-2 font-mono text-xs uppercase">
            {(["upcoming", "past"] as const).map((t) => (
              <button key={t} onClick={() => setTab(t)}
                className={`rounded-md px-3 py-2 ${tab === t ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`}>
                {t} ({t === "upcoming" ? upcoming.length : past.length})
              </button>
            ))}
          </div>
          <div className="mt-5 space-y-4">
            {isLoading && <p className="text-muted-foreground">Loading…</p>}
            {!isLoading && list.length === 0 && <p className="text-muted-foreground">Nothing here yet.</p>}
            {list.map((p) => (
              <Card key={p.id} p={p} mine={!!user && p.author_id === user.id} onDelete={() => remove(p.id)} />
            ))}
          </div>
        </section>

        <aside className="space-y-6">
          {!user ? (
            <div className="rounded-lg border border-border bg-card p-5">
              <h2 className="font-display font-semibold">Post your own calls</h2>
              <p className="mt-1 text-sm text-muted-foreground">Sign in to write predictions or ask the AI for one.</p>
              <Link to="/auth" className="mt-4 inline-block rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Sign in</Link>
            </div>
          ) : (
            <>
              <div className="rounded-lg border border-border bg-card p-5">
                <h2 className="font-display font-semibold">Ask the AI</h2>
                <select className={`${input} mt-3`} value={aiSymbol} onChange={(e) => setAiSymbol(e.target.value)}>
                  {ASSETS.map((a) => <option key={a.symbol} value={a.symbol}>{a.name} ({a.symbol})</option>)}
                </select>
                <button disabled={aiBusy} onClick={runAi} className="mt-3 w-full rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50">
                  {aiBusy ? "Thinking…" : "Generate prediction"}
                </button>
              </div>
              <form onSubmit={submit} className="space-y-3 rounded-lg border border-border bg-card p-5">
                <h2 className="font-display font-semibold">Write a prediction</h2>
                <input required maxLength={20} placeholder="Symbol (e.g. AAPL)" className={input} value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value })} />
                <input required maxLength={80} placeholder="Headline" className={input} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
                <textarea required maxLength={600} rows={3} placeholder="Your reasoning" className={input} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
                <div className="grid grid-cols-2 gap-2">
                  <select className={input} value={form.direction} onChange={(e) => setForm({ ...form, direction: e.target.value })}>
                    <option value="bullish">Bullish</option><option value="bearish">Bearish</option><option value="neutral">Neutral</option>
                  </select>
                  <input required type="date" className={input} value={form.target_date} onChange={(e) => setForm({ ...form, target_date: e.target.value })} />
                </div>
                <button className="w-full rounded-md border border-primary px-4 py-2 text-sm font-medium text-primary hover:bg-primary hover:text-primary-foreground">Post</button>
              </form>
            </>
          )}
        </aside>
      </main>
    </div>
  );
}
