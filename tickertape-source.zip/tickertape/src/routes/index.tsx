import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { Sparkline } from "@/components/Sparkline";
import { ASSETS, HEADLINES, fmt, quote } from "@/lib/market";
import { useLiveQuotes } from "@/lib/use-live";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TickerTape — Global market updates" },
      { name: "description", content: "Live-style updates across US, India, Europe, Japan and crypto markets." },
      { property: "og:title", content: "TickerTape — Global market updates" },
      { property: "og:description", content: "Track global indices, top stocks and market headlines in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});


function Change({ pct }: { pct: number }) {
  return (
    <span className={`font-mono text-sm ${pct >= 0 ? "text-gain" : "text-loss"}`}>
      {pct >= 0 ? "▲" : "▼"} {Math.abs(pct).toFixed(2)}%
    </span>
  );
}

function Index() {
  const { data: live } = useLiveQuotes(ASSETS.map((a) => a.symbol));
  const quotes = ASSETS.map((a) => ({ a, q: live?.[a.symbol] ?? quote(a) }));
  const indices = quotes.filter((x) => x.a.kind === "index");
  const movers = quotes.filter((x) => x.a.kind !== "index").sort((x, y) => Math.abs(y.q.pct) - Math.abs(x.q.pct));

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="overflow-hidden border-b border-border bg-card py-2">
        <div className="animate-marquee flex w-max gap-10 whitespace-nowrap font-mono text-xs">
          {[...quotes, ...quotes].map(({ a, q }, i) => (
            <span key={i}>
              <span className="text-muted-foreground">{a.symbol}</span> {fmt(q.price)} <Change pct={q.pct} />
            </span>
          ))}
        </div>
      </div>

      <main className="mx-auto max-w-6xl px-5 py-10">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">{live ? "● Live · refreshes every 30s" : "● Connecting to live prices…"}</p>
            <h1 className="mt-2 font-display text-4xl font-bold md:text-5xl">The world's markets, at a glance.</h1>
          </div>
          <Link to="/predictions" className="rounded-md bg-primary px-4 py-2 font-medium text-primary-foreground hover:opacity-90">
            Read predictions →
          </Link>
        </div>

        <section className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-border bg-border md:grid-cols-3">
          {indices.map(({ a, q }) => (
            <div key={a.symbol} className="bg-card p-5">
              <div className="flex justify-between font-mono text-xs text-muted-foreground">
                <span>{a.name}</span>
                <span>{a.region}</span>
              </div>
              <div className="mt-2 font-display text-2xl font-semibold">{fmt(q.price)}</div>
              <Change pct={q.pct} />
              <Sparkline data={q.series} up={q.pct >= 0} />
            </div>
          ))}
        </section>

        <div className="mt-10 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
          <section>
            <h2 className="mb-3 font-mono text-xs uppercase tracking-widest text-muted-foreground">Top movers</h2>
            <div className="rounded-lg border border-border bg-card">
              {movers.map(({ a, q }) => (
                <div key={a.symbol} className="flex items-center justify-between border-b border-border px-4 py-3 last:border-0">
                  <div>
                    <div className="font-medium">{a.name}</div>
                    <div className="font-mono text-xs text-muted-foreground">{a.symbol} · {a.region}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono">{fmt(q.price)}</div>
                    <Change pct={q.pct} />
                  </div>
                </div>
              ))}
            </div>
          </section>
          <section>
            <h2 className="mb-3 font-mono text-xs uppercase tracking-widest text-muted-foreground">Latest updates</h2>
            <ul className="space-y-3">
              {HEADLINES.map((h) => (
                <li key={h.text} className="rounded-lg border border-border bg-card p-4">
                  <div className="flex justify-between font-mono text-xs text-muted-foreground">
                    <span className="text-primary">{h.region}</span>
                    <span>{h.time} ago</span>
                  </div>
                  <p className="mt-1">{h.text}</p>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </main>
    </div>
  );
}
