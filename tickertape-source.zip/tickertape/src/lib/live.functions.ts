import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type LiveQuote = { price: number; change: number; pct: number; series: number[]; currency: string; time: number };

async function fetchOne(symbol: string): Promise<[string, LiveQuote] | null> {
  try {
    const res = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=1d&interval=5m`,
      { headers: { "User-Agent": "Mozilla/5.0" } },
    );
    if (!res.ok) return null;
    const json = (await res.json()) as {
      chart?: { result?: Array<{ meta: Record<string, number | string>; indicators: { quote: Array<{ close: (number | null)[] }> } }> };
    };
    const r = json.chart?.result?.[0];
    if (!r) return null;
    const price = Number(r.meta["regularMarketPrice"]);
    const prev = Number(r.meta["chartPreviousClose"] ?? r.meta["previousClose"] ?? price);
    const series = (r.indicators.quote[0]?.close ?? []).filter((v): v is number => typeof v === "number");
    return [
      symbol,
      {
        price,
        change: price - prev,
        pct: prev ? ((price - prev) / prev) * 100 : 0,
        series: series.length > 1 ? series : [prev, price],
        currency: String(r.meta["currency"] ?? ""),
        time: Number(r.meta["regularMarketTime"] ?? 0) * 1000,
      },
    ];
  } catch {
    return null;
  }
}

export const getLiveQuotes = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ symbols: z.array(z.string().max(20)).max(40) }).parse(d))
  .handler(async ({ data }) => {
    const rows = await Promise.all(data.symbols.map(fetchOne));
    return Object.fromEntries(rows.filter((r): r is [string, LiveQuote] => r !== null));
  });
