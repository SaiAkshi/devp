export type Asset = { symbol: string; name: string; region: string; base: number; kind: "index" | "stock" | "crypto" };

export const ASSETS: Asset[] = [
  { symbol: "^GSPC", name: "S&P 500", region: "US", base: 5980, kind: "index" },
  { symbol: "^IXIC", name: "Nasdaq", region: "US", base: 19210, kind: "index" },
  { symbol: "^NSEI", name: "Nifty 50", region: "India", base: 24350, kind: "index" },
  { symbol: "^FTSE", name: "FTSE 100", region: "UK", base: 8120, kind: "index" },
  { symbol: "^N225", name: "Nikkei 225", region: "Japan", base: 39400, kind: "index" },
  { symbol: "^GDAXI", name: "DAX", region: "Germany", base: 19650, kind: "index" },
  { symbol: "AAPL", name: "Apple", region: "US", base: 228.4, kind: "stock" },
  { symbol: "NVDA", name: "Nvidia", region: "US", base: 146.2, kind: "stock" },
  { symbol: "TSLA", name: "Tesla", region: "US", base: 312.8, kind: "stock" },
  { symbol: "RELIANCE.NS", name: "Reliance", region: "India", base: 2895, kind: "stock" },
  { symbol: "TCS.NS", name: "TCS", region: "India", base: 4120, kind: "stock" },
  { symbol: "7203.T", name: "Toyota", region: "Japan", base: 2710, kind: "stock" },
  { symbol: "SAP.DE", name: "SAP", region: "Germany", base: 221.5, kind: "stock" },
  { symbol: "BTC-USD", name: "Bitcoin", region: "Crypto", base: 76400, kind: "crypto" },
];

// Deterministic pseudo-random so server and client render the same first frame.
function rand(seed: number) {
  const x = Math.sin(seed * 9301 + 49297) * 233280;
  return x - Math.floor(x);
}

export function series(asset: Asset, points = 40, tick = 0) {
  const seed = asset.symbol.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const vol = asset.kind === "crypto" ? 0.012 : asset.kind === "stock" ? 0.007 : 0.004;
  const out: number[] = [];
  let v = asset.base;
  for (let i = 0; i < points + tick; i++) {
    v = v * (1 + (rand(seed + i) - 0.48) * vol);
    out.push(v);
  }
  return out.slice(-points);
}

export function quote(asset: Asset, tick = 0) {
  const s = series(asset, 40, tick);
  const price = s[s.length - 1] ?? asset.base;
  const open = s[0] ?? asset.base;
  return { price, change: price - open, pct: ((price - open) / open) * 100, series: s };
}

export const HEADLINES = [
  { region: "US", text: "Fed signals patience as inflation cools toward target", time: "12m" },
  { region: "India", text: "Nifty hits fresh high on strong FII inflows into banks", time: "34m" },
  { region: "Japan", text: "Yen firms after BoJ hints at gradual tightening path", time: "1h" },
  { region: "Europe", text: "DAX edges up as auto stocks rebound on China demand", time: "2h" },
  { region: "Crypto", text: "Bitcoin ETF inflows top $1B for third straight week", time: "3h" },
  { region: "UK", text: "FTSE miners slip as copper prices retreat", time: "4h" },
];

export const fmt = (n: number) =>
  n.toLocaleString("en-US", { maximumFractionDigits: n > 1000 ? 0 : 2, minimumFractionDigits: n > 1000 ? 0 : 2 });
