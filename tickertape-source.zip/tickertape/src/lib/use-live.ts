import { useQuery } from "@tanstack/react-query";
import { getLiveQuotes, type LiveQuote } from "./live.functions";

/** Real prices, refreshed every 30 seconds. */
export function useLiveQuotes(symbols: string[]) {
  return useQuery({
    queryKey: ["live", symbols.join(",")],
    queryFn: () => getLiveQuotes({ data: { symbols } }) as Promise<Record<string, LiveQuote>>,
    refetchInterval: 30_000,
    staleTime: 20_000,
  });
}
