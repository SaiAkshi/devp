import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const generateAiPrediction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ symbol: z.string().min(1).max(20), name: z.string().max(80), price: z.number() }).parse(d),
  )
  .handler(async ({ data }) => {
    const { createOpenAI } = await import("@ai-sdk/openai");
    const { streamText } = await import("ai");
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI is not configured");
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });
    const today = new Date().toISOString().slice(0, 10);
    const result = streamText({
      model: provider.responses("openai/gpt-6-astra"),
      prompt: `Today is ${today}. Write a short, balanced market prediction for ${data.name} (${data.symbol}), currently around ${data.price}. This is illustrative, not financial advice.
Reply ONLY with JSON: {"title": string (max 60 chars), "body": string (2-3 sentences), "direction": "bullish"|"bearish"|"neutral", "days": integer 7-60}`,
      providerOptions: {
        openai: {
          store: false,
          forceReasoning: true,
          reasoningEffort: "low",
          include: ["reasoning.encrypted_content"],
        },
      },
    });
    const text = await result.text;
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) throw new Error("AI returned an unexpected answer");
    const p = z
      .object({
        title: z.string(),
        body: z.string(),
        direction: z.enum(["bullish", "bearish", "neutral"]),
        days: z.number(),
      })
      .parse(JSON.parse(match[0]));
    const target = new Date(Date.now() + Math.min(60, Math.max(7, p.days)) * 86400000)
      .toISOString()
      .slice(0, 10);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("predictions").insert({
      symbol: data.symbol,
      title: p.title.slice(0, 80),
      body: p.body,
      direction: p.direction,
      target_date: target,
      source: "ai",
      author_name: "Market AI",
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
