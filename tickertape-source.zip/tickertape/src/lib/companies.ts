import { quote, type Asset } from "./market";

export type Company = Asset & { margin: number; insight: string };

export const REGIONS = [
  { slug: "us", label: "United States", index: "S&P 500" },
  { slug: "india", label: "India", index: "Nifty 50" },
  { slug: "uk", label: "United Kingdom", index: "FTSE 100" },
  { slug: "japan", label: "Japan", index: "Nikkei 225" },
  { slug: "germany", label: "Germany", index: "DAX" },
  { slug: "crypto", label: "Crypto", index: "Top coins" },
] as const;

export type RegionSlug = (typeof REGIONS)[number]["slug"];

const c = (symbol: string, name: string, region: string, base: number, margin: number, insight: string): Company => ({
  symbol, name, region, base, margin, insight, kind: region === "Crypto" ? "crypto" : "stock",
});

export const COMPANIES: Record<RegionSlug, Company[]> = {
  us: [
    c("AAPL", "Apple", "US", 228.4, 26, "Services now drive over a quarter of revenue at much higher margins than hardware."),
    c("MSFT", "Microsoft", "US", 418.2, 36, "Azure AI workloads are the fastest-growing slice of its cloud business."),
    c("NVDA", "Nvidia", "US", 146.2, 55, "Data-center chips remain supply-constrained with orders booked well ahead."),
    c("GOOGL", "Alphabet", "US", 178.9, 28, "Cloud turned solidly profitable while Search ad revenue keeps compounding."),
    c("META", "Meta", "US", 582.1, 35, "Cost discipline plus AI-driven ad targeting lifted margins to record levels."),
  ],
  india: [
    c("RELIANCE.NS", "Reliance Industries", "India", 2895, 9, "Jio and Retail now contribute more profit than the legacy oil-to-chemicals arm."),
    c("TCS.NS", "TCS", "India", 4120, 19, "Large multi-year deal wins give strong revenue visibility despite slow IT spend."),
    c("HDFCBANK.NS", "HDFC Bank", "India", 1720, 22, "Post-merger deposit growth is the key number markets are watching."),
    c("INFY.NS", "Infosys", "India", 1890, 17, "Generative-AI service deals are a growing share of its new contract pipeline."),
    c("ITC.NS", "ITC", "India", 478, 28, "Cigarette cash flows fund steady expansion in FMCG and hotels."),
  ],
  uk: [
    c("SHEL.L", "Shell", "UK", 2580, 11, "Aggressive buybacks continue, funded by strong LNG trading profits."),
    c("AZN.L", "AstraZeneca", "UK", 11240, 15, "Oncology pipeline is driving double-digit revenue growth."),
    c("HSBA.L", "HSBC", "UK", 712, 30, "Higher-for-longer rates in Asia keep net interest income elevated."),
    c("ULVR.L", "Unilever", "UK", 4720, 14, "Portfolio simplification and the ice-cream spin-off aim to lift margins."),
  ],
  japan: [
    c("7203.T", "Toyota", "Japan", 2710, 11, "Hybrid demand is outpacing pure EVs, playing to Toyota's strengths."),
    c("6758.T", "Sony", "Japan", 3150, 9, "Gaming and image sensors carry the bulk of operating profit."),
    c("8035.T", "Tokyo Electron", "Japan", 24800, 25, "Chip-equipment orders track the global AI build-out closely."),
    c("6861.T", "Keyence", "Japan", 68500, 52, "Industry-leading margins from a direct-sales factory-automation model."),
  ],
  germany: [
    c("SAP.DE", "SAP", "Germany", 221.5, 20, "Cloud migration of its ERP customers is lifting recurring revenue."),
    c("SIE.DE", "Siemens", "Germany", 182.4, 12, "Digital industries and smart-infrastructure backlog sits near record highs."),
    c("ALV.DE", "Allianz", "Germany", 284.6, 9, "Steady insurance premiums plus higher bond yields support earnings."),
    c("DTE.DE", "Deutsche Telekom", "Germany", 28.9, 10, "Majority stake in T-Mobile US is the main profit engine."),
  ],
  crypto: [
    c("BTC-USD", "Bitcoin", "Crypto", 76400, 0, "Spot ETF inflows have become the dominant source of new demand."),
    c("ETH-USD", "Ethereum", "Crypto", 3120, 0, "Fee revenue shifts to layer-2 networks as main-chain activity matures."),
    c("SOL-USD", "Solana", "Crypto", 188, 0, "Developer and trading activity keep rising on the network."),
  ],
};

/** Simple trend rule: compares recent move against earlier move in the sample series. */
export function trendCall(co: Company, live?: { price: number; change: number; pct: number; series: number[] }) {
  const q = live ?? quote(co);
  const s = q.series;
  const ref = s[Math.max(0, s.length - 11)] ?? q.price;
  const recent = (q.price - ref) / ref;
  const direction = q.pct > 0.5 && recent > 0 ? "bullish" : q.pct < -0.5 && recent < 0 ? "bearish" : "neutral";
  const text =
    direction === "bullish"
      ? `Uptrend intact — momentum suggests further gains near term.`
      : direction === "bearish"
        ? `Downtrend in play — expect weakness until support holds.`
        : `Range-bound — likely to drift sideways until a catalyst.`;
  return { ...q, direction, text };
}
