import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { REGIONS } from "@/lib/companies";
import type { User } from "@supabase/supabase-js";

export function useUser() {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  return user;
}

export function SiteHeader() {
  const user = useUser();
  const link = "font-mono text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground";
  return (
    <header className="border-b border-border">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link to="/" className="font-display text-xl font-bold tracking-tight">
          Ticker<span className="text-primary">/</span>Tape
        </Link>
        <nav className="flex items-center gap-6">
          <Link to="/" className={link} activeProps={{ className: "text-primary" }} activeOptions={{ exact: true }}>
            Markets
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger className={link}>Regions ▾</DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {REGIONS.map((r) => (
                <DropdownMenuItem key={r.slug} asChild>
                  <Link to="/market/$region" params={{ region: r.slug }}>{r.label}</Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Link to="/predictions" className={link} activeProps={{ className: "text-primary" }}>
            Predictions
          </Link>
          {user ? (
            <button className={link} onClick={() => supabase.auth.signOut()}>
              Sign out
            </button>
          ) : (
            <Link to="/auth" className={link}>
              Sign in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
