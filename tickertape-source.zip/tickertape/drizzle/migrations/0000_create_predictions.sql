CREATE TABLE public.predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  direction TEXT NOT NULL DEFAULT 'neutral',
  target_date DATE NOT NULL,
  source TEXT NOT NULL DEFAULT 'user',
  author_id UUID,
  author_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.predictions TO anon;
GRANT SELECT, INSERT, DELETE ON public.predictions TO authenticated;
GRANT ALL ON public.predictions TO service_role;
ALTER TABLE public.predictions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read predictions" ON public.predictions FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users post own predictions" ON public.predictions FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id AND source = 'user' AND direction IN ('bullish','bearish','neutral'));
CREATE POLICY "Users delete own predictions" ON public.predictions FOR DELETE TO authenticated USING (auth.uid() = author_id);

INSERT INTO public.predictions (symbol, title, body, direction, target_date, source, author_name, created_at) VALUES
('AAPL','Services revenue carries Q4','Expect Apple to beat on services margins, lifting shares toward new highs after earnings.','bullish', CURRENT_DATE - 20,'ai','Market AI', now() - interval '40 days'),
('^N225','Nikkei cools after rally','Yen strength likely pressures exporters; a 3-5% pullback is plausible.','bearish', CURRENT_DATE - 7,'ai','Market AI', now() - interval '25 days'),
('RELIANCE.NS','Retail spin-off momentum','Valuation unlock narrative should keep Reliance range-bound to positive.','bullish', CURRENT_DATE - 3,'ai','Market AI', now() - interval '18 days'),
('NVDA','AI capex stays strong','Data-center demand continues; dips likely bought ahead of next earnings.','bullish', CURRENT_DATE + 14,'ai','Market AI', now() - interval '2 days'),
('^FTSE','Energy weighs on London','Lower crude prices may drag FTSE 100 heavyweights into month end.','bearish', CURRENT_DATE + 21,'ai','Market AI', now() - interval '1 day'),
('BTC-USD','Sideways into year end','Crypto likely consolidates in a wide range until macro clarity improves.','neutral', CURRENT_DATE + 45,'ai','Market AI', now());